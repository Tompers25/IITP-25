#include <bits/stdc++.h>
using namespace std;

#define len 9

//stl containers to store initial state, target state and parent state
vector<int> initial_state;
vector<int> goal_state;
vector<vector<int> > path;

/*********** HEURISTIC FUNCTIONS ***************/
// function to calculate the number of displaced tile in the
//current state, as compared to the target
//state
int num_displaced_tiles(vector<int> &curr_state)
{
    int num = 0;

    for(int i=0; i<len; i++)
    {
        //if current tile is not same as the
        //tile in the goal state, increase
        //count
        if(curr_state[i] != goal_state[i] && curr_state[i] != 0)
            num++;

    }

    return num;
}

//function to calculate the manhattan distance for all the displaced
//tiles in the current state
int manhattan_distance(vector<int> &curr_state)
{
    int dist = 0;

    for(int i=0; i<len; i++)
    {
        for(int j=0; j<len; j++)
        {
            //if ith tile of current state is same as
            //jth tile of goal state, add the difference
            //in index to the total distance
            if(curr_state[i] == goal_state[j] && curr_state[i]!= 0)
                dist += (abs(i%3 - j%3) + abs(i/3 - j/3));
        }
    }

    return dist;
}

//function to check if current state is same as the target state
bool check_for_state(vector<int> &state, vector<int> &target_state)
{
    for(int i=0; i<len; i++)
    {
        //if any tile is found different,
        //return false;
        if(state[i] != target_state[i])
            return false;
    }

    //else return true;
    return true;
}

//function to find the index of the blank tile
int find_blank_tile(vector<int> &state)
{
    int index = 0;
    //iterates through the current state and
    //searches for the blank tile
    for(int i=0; i<len; i++)
    {
        if(state[i] == 0)
        {
            index = i;
            break;
        }
    }

    return index;
}

//generates all the children nodes of the current state
//compares the cost function of all the children nodes
//and returns the node with the least cost function
pair<int, vector<int> >expand_state(vector<int> &curr_state, bool type)
{
    vector<int> copy = curr_state;
    pair<int, vector<int> >result;
    int cost = 0;
    int ans = INT_MAX;

    //find the blank tile
    int index = find_blank_tile(curr_state);

    //move up
    if(index + 3 < len)
    {
        //swap the tiles
        swap(curr_state[index], curr_state[index + 3]);
        //calculate cost function
        if(type == 1)
            cost = num_displaced_tiles(curr_state);
        else
            cost = manhattan_distance(curr_state);
        if(ans > cost)
        {
            ans = cost;
            result = {ans, curr_state};
        }
        //swap the tiles back
        swap(curr_state[index], curr_state[index + 3]);
    }
    //move down
    if(index - 3 > 0)
    {
        swap(curr_state[index], curr_state[index - 3]);
        if(type == 1)
            cost = num_displaced_tiles(curr_state);
        else
            cost = manhattan_distance(curr_state);
        if(ans > cost)
        {
            ans = cost;
            result = {ans, curr_state};
        }
        swap(curr_state[index], curr_state[index - 3]);
    }
    //move right
    if(index + 1 < len && (index+1)%3 != 0)
    {
        swap(curr_state[index], curr_state[index + 1]);
        if(type == 1)
            cost = num_displaced_tiles(curr_state);
        else
            cost = manhattan_distance(curr_state);
        if(ans > cost)
        {
            ans = cost;
            result = {ans, curr_state};
        }
        swap(curr_state[index], curr_state[index + 1]);
    }
    //move left
    if(index - 1 > 0 && (index-1)%3 != 2)
    {
        swap(curr_state[index], curr_state[index - 1]);
        if(type == 1)
            cost = num_displaced_tiles(curr_state);
        else
            cost = manhattan_distance(curr_state);
        if(ans > cost)
        {
            ans = cost;
            result = {ans, curr_state};
        }
        swap(curr_state[index], curr_state[index - 1]);
    }

    return result;
}

//function to print the current state
void print_state(vector<int> &state)
{
    for(int i=0; i<len; i++)
    {
        cout<<state[i]<<" ";
        if(i%3 == 2)
            cout<<"\n";
    }

    return;
}

//function that implements the serching method
void search(vector<int> state, bool type)
{
    //calculate the cost associated with the current state
    int f_cost = 0;
    if(type == 1)
        f_cost = num_displaced_tiles(state);
    else if(type == 0)
        f_cost = manhattan_distance(state);

    vector<int>curr_state = state;
    bool flag = false;
    bool check = true;
    int sideways_travel = 0;
    int num_steps = 0;

    while(check == true)
    {
        //one more state explored
        num_steps++;

        //check if the current state is goal state
        flag = check_for_state(curr_state, goal_state);
        if(flag == true)
            break;
        
        //if not, expand the current state
        pair<int, vector<int> > next_state;
        path.push_back(curr_state);
        next_state = expand_state(curr_state, type);

        //if cost of next state is less than current state,
        //update the current state to be explored
        if(next_state.first < f_cost)
        {
            curr_state = next_state.second;
            f_cost = next_state.first;
        }
        //if cost of next function is same as the current state,
        //move sideways
        else if(next_state.first == f_cost && sideways_travel<100)
        {
            curr_state = next_state.second;
            f_cost = next_state.first;
            sideways_travel++;
        }
        //else, we have reached maxima, exit
        else
        {
            check = false;
        }
    }

    vector<int> target_state = goal_state;
    //if we have reached the goal state, print:
    if(flag == true)
    {
        if(type == 1)
            cout<<"Using heurestics = Number of displaced tiles\n";
        else
            cout<<"Using heuristics = Manhattan distance\n";
        cout<<"Reached!\n";
        cout<<"Starting state : \n";
        print_state(state);
        cout<<"\nTarget State: \n";
        print_state(target_state);
        cout<<"\nNumber of states explored: "<<num_steps<<"\n";
        cout<<"Optimal path cost: "<<num_steps<<"\n";
        cout<<"Optimal Path: \n";
        for(int i=0; i<path.size(); i++)
        {
            print_state(path[i]);
            cout<<"\n";
        }
        print_state(target_state);
        cout<<"Time taken: "<<clock()*1000.0 / CLOCKS_PER_SEC <<"ms\n\n";
    }
    //else, print:
    else
    {
        if(type == 1)
            cout<<"Using heurestics = Number of displaced tiles\n";
        else
            cout<<"Using heuristics = Manhattan distance\n";
        cout<<"Not reachable.\n";
        cout<<"Starting state : \n";
        print_state(state);
        cout<<"\nTarget State: \n";
        print_state(target_state);
        cout<<"\nNumber of states explored: "<<num_steps<<"\n";
        cout<<"Time taken: "<<clock()*1000.0 / CLOCKS_PER_SEC <<"ms\n\n";
    }

    return;
}

//driver function
int main()
{
    //randomly generated input  
    initial_state = {1, 2, 3, 4, 5, 6, 7, 8, 0};
    random_shuffle (initial_state.begin(), initial_state.end());

    //initial_state = {0, 1, 3, 4, 2, 5, 7, 8, 6};

    //initial_state = {1, 5, 2, 0, 8, 3, 4, 7, 6};

    //initial_state = {1, 2, 3, 4, 5, 6, 0, 7, 8};

    goal_state = {1, 2, 3, 4, 5, 6, 7, 8, 0};
    
    
    search(initial_state, 0);
    path.clear();
    search(initial_state, 1);

    return 0;
}